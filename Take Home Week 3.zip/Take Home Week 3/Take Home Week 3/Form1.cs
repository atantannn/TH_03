﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home_Week_3
{
    public partial class Form1 : Form
    {
        List <string> user = new List<string>();
        string username;
        string password;
        int balance;
        int nominal;
        public Form1()
        {
            InitializeComponent();
            panel_regis.Visible = false;
            panel_deposit.Visible = false;
            panel_balance.Visible = false;
            panel_withdraw.Visible = false; 
        
        }
        
        
        private void btn_register_Click(object sender, EventArgs e)
        {
            panel_regis.Visible = true;
            panel_login.Visible = false;

        }
        

        private void btn_login_Click(object sender, EventArgs e)
        {
            username = txtbox_usn.Text;
            password = txtbox_usn.Text;

            if(string.IsNullOrEmpty (username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and Password not found.");
            }
            

           foreach (string users in user)
           {
                if (user.Contains(users))
                {
                    MessageBox.Show("Login Successful");
                    panel_balance.Visible = true;
                    panel_login.Visible = false;
                    return;
                }
                
           }
           MessageBox.Show("Username and Password not found.");
            
            txtbox_usn.Clear();
            txtbox_pass.Clear();

            


        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
           panel_login.Visible = false;
           panel_balance.Visible = false;
           panel_deposit.Visible = true;
            
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
           MessageBox.Show("Log Out Berhasil.");
           panel_deposit.Visible = false;
           panel_balance.Visible = false;
           panel_regis.Visible = false;
           panel_withdraw.Visible = false;
           panel_login.Visible = true;
           txtbox_usn.Clear ();
           txtbox_pass.Clear ();
        }

        private void btn_regis_Click(object sender, EventArgs e)
        {
            string usnregis = txtbox_usnregis.Text;
            if (user.Contains(usnregis))
            {
                MessageBox.Show("Username has been used");
                txtbox_passregis.Clear();
                txtbox_usnregis.Clear();
                return;
            }
            else
            {
                user.Add(usnregis);
                MessageBox.Show("Register Successful");
                
            }
            panel_login.Visible = true;
            panel_regis.Visible = false;
            txtbox_passregis.Clear();
            txtbox_usnregis.Clear();
        }


        private void btn_deposituang_Click(object sender, EventArgs e)
        {
            int nominaldeposit = Convert.ToInt32(txtbox_deposit.Text);
            balance += nominaldeposit;
            string nominalnyaa = balance.ToString("C");
            lb_nominal.Text = nominalnyaa;
            if (nominaldeposit <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
            else
            {
                MessageBox.Show("Succesfully Add Deposit");
            }
           
            panel_login.Visible = false;
            panel_deposit.Visible = false;
            panel_balance.Visible = true;
            txtbox_deposit.Clear();
        }

        private void btn_withdrawuang_Click(object sender, EventArgs e)
        {
            int nominaldeposit = Convert.ToInt32(txtbox_withdraw.Text);
            if (nominaldeposit > balance || nominaldeposit <= 0)
            {
                MessageBox.Show("Saldo tidak cukup");
            }
            else
            {
                balance -= nominaldeposit;
                string nominalnyaa = balance.ToString("C");
                lb_nominal.Text = nominalnyaa;
                MessageBox.Show("Berhasil.");
            }
            lb_nominalshow.Text = lb_nominal.Text;
            panel_balance.Visible = false;
            panel_login.Visible = false;
            txtbox_withdraw.Clear();

        }

        private void btn_wd_Click(object sender, EventArgs e)
        {
            panel_balance.Visible = false;
            panel_withdraw.Visible = true;
            
            
            
        }
    }
}
