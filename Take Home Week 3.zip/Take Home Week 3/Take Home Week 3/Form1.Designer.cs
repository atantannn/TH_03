﻿namespace Take_Home_Week_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.txtbox_usn = new System.Windows.Forms.TextBox();
            this.txtbox_pass = new System.Windows.Forms.TextBox();
            this.lb_usn = new System.Windows.Forms.Label();
            this.lb_pass = new System.Windows.Forms.Label();
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.panel_regis = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_regis = new System.Windows.Forms.Button();
            this.lb_usnpass = new System.Windows.Forms.Label();
            this.txtbox_usnregis = new System.Windows.Forms.TextBox();
            this.lb_usnregis = new System.Windows.Forms.Label();
            this.txtbox_passregis = new System.Windows.Forms.TextBox();
            this.panel_balance = new System.Windows.Forms.Panel();
            this.lb_nominal = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.btn_wd = new System.Windows.Forms.Button();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_logout = new System.Windows.Forms.Button();
            this.lb_ucbank2 = new System.Windows.Forms.Label();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.txtbox_deposit = new System.Windows.Forms.TextBox();
            this.lb_input = new System.Windows.Forms.Label();
            this.btn_deposituang = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbox_withdraw = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_withdrawuang = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_login = new System.Windows.Forms.Panel();
            this.lb_balanceshow = new System.Windows.Forms.Label();
            this.lb_nominalshow = new System.Windows.Forms.Label();
            this.panel_regis.SuspendLayout();
            this.panel_balance.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.panel_login.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(76, 154);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 27);
            this.btn_login.TabIndex = 0;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(76, 202);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(75, 27);
            this.btn_register.TabIndex = 1;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // txtbox_usn
            // 
            this.txtbox_usn.Location = new System.Drawing.Point(92, 68);
            this.txtbox_usn.Name = "txtbox_usn";
            this.txtbox_usn.Size = new System.Drawing.Size(130, 22);
            this.txtbox_usn.TabIndex = 2;
            // 
            // txtbox_pass
            // 
            this.txtbox_pass.Location = new System.Drawing.Point(92, 110);
            this.txtbox_pass.Name = "txtbox_pass";
            this.txtbox_pass.Size = new System.Drawing.Size(130, 22);
            this.txtbox_pass.TabIndex = 3;
            // 
            // lb_usn
            // 
            this.lb_usn.AutoSize = true;
            this.lb_usn.Location = new System.Drawing.Point(16, 68);
            this.lb_usn.Name = "lb_usn";
            this.lb_usn.Size = new System.Drawing.Size(76, 16);
            this.lb_usn.TabIndex = 4;
            this.lb_usn.Text = "Username :";
            // 
            // lb_pass
            // 
            this.lb_pass.AutoSize = true;
            this.lb_pass.Location = new System.Drawing.Point(16, 113);
            this.lb_pass.Name = "lb_pass";
            this.lb_pass.Size = new System.Drawing.Size(73, 16);
            this.lb_pass.TabIndex = 5;
            this.lb_pass.Text = "Password :";
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(71, 4);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(114, 29);
            this.lb_ucbank.TabIndex = 6;
            this.lb_ucbank.Text = "UC Bank";
            // 
            // panel_regis
            // 
            this.panel_regis.Controls.Add(this.label1);
            this.panel_regis.Controls.Add(this.btn_regis);
            this.panel_regis.Controls.Add(this.lb_usnpass);
            this.panel_regis.Controls.Add(this.txtbox_usnregis);
            this.panel_regis.Controls.Add(this.lb_usnregis);
            this.panel_regis.Controls.Add(this.txtbox_passregis);
            this.panel_regis.Location = new System.Drawing.Point(788, 51);
            this.panel_regis.Name = "panel_regis";
            this.panel_regis.Size = new System.Drawing.Size(259, 239);
            this.panel_regis.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(67, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "UC Bank";
            // 
            // btn_regis
            // 
            this.btn_regis.Location = new System.Drawing.Point(72, 175);
            this.btn_regis.Name = "btn_regis";
            this.btn_regis.Size = new System.Drawing.Size(75, 27);
            this.btn_regis.TabIndex = 8;
            this.btn_regis.Text = "Register";
            this.btn_regis.UseVisualStyleBackColor = true;
            this.btn_regis.Click += new System.EventHandler(this.btn_regis_Click);
            // 
            // lb_usnpass
            // 
            this.lb_usnpass.AutoSize = true;
            this.lb_usnpass.Location = new System.Drawing.Point(16, 127);
            this.lb_usnpass.Name = "lb_usnpass";
            this.lb_usnpass.Size = new System.Drawing.Size(73, 16);
            this.lb_usnpass.TabIndex = 11;
            this.lb_usnpass.Text = "Password :";
            // 
            // txtbox_usnregis
            // 
            this.txtbox_usnregis.Location = new System.Drawing.Point(92, 82);
            this.txtbox_usnregis.Name = "txtbox_usnregis";
            this.txtbox_usnregis.Size = new System.Drawing.Size(130, 22);
            this.txtbox_usnregis.TabIndex = 8;
            // 
            // lb_usnregis
            // 
            this.lb_usnregis.AutoSize = true;
            this.lb_usnregis.Location = new System.Drawing.Point(16, 82);
            this.lb_usnregis.Name = "lb_usnregis";
            this.lb_usnregis.Size = new System.Drawing.Size(76, 16);
            this.lb_usnregis.TabIndex = 10;
            this.lb_usnregis.Text = "Username :";
            // 
            // txtbox_passregis
            // 
            this.txtbox_passregis.Location = new System.Drawing.Point(92, 124);
            this.txtbox_passregis.Name = "txtbox_passregis";
            this.txtbox_passregis.Size = new System.Drawing.Size(130, 22);
            this.txtbox_passregis.TabIndex = 9;
            // 
            // panel_balance
            // 
            this.panel_balance.Controls.Add(this.lb_nominal);
            this.panel_balance.Controls.Add(this.lb_balance);
            this.panel_balance.Controls.Add(this.btn_wd);
            this.panel_balance.Controls.Add(this.btn_deposit);
            this.panel_balance.Controls.Add(this.btn_logout);
            this.panel_balance.Controls.Add(this.lb_ucbank2);
            this.panel_balance.Location = new System.Drawing.Point(788, 54);
            this.panel_balance.Name = "panel_balance";
            this.panel_balance.Size = new System.Drawing.Size(335, 321);
            this.panel_balance.TabIndex = 8;
            // 
            // lb_nominal
            // 
            this.lb_nominal.AutoSize = true;
            this.lb_nominal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nominal.Location = new System.Drawing.Point(131, 111);
            this.lb_nominal.Name = "lb_nominal";
            this.lb_nominal.Size = new System.Drawing.Size(80, 25);
            this.lb_nominal.TabIndex = 16;
            this.lb_nominal.Text = "Rp0,00";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(62, 116);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(57, 16);
            this.lb_balance.TabIndex = 15;
            this.lb_balance.Text = "Balance";
            // 
            // btn_wd
            // 
            this.btn_wd.Location = new System.Drawing.Point(130, 190);
            this.btn_wd.Name = "btn_wd";
            this.btn_wd.Size = new System.Drawing.Size(93, 27);
            this.btn_wd.TabIndex = 14;
            this.btn_wd.Text = "Withdraw";
            this.btn_wd.UseVisualStyleBackColor = true;
            this.btn_wd.Click += new System.EventHandler(this.btn_wd_Click);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(130, 148);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(93, 27);
            this.btn_deposit.TabIndex = 13;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(223, 50);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(75, 27);
            this.btn_logout.TabIndex = 12;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // lb_ucbank2
            // 
            this.lb_ucbank2.AutoSize = true;
            this.lb_ucbank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank2.Location = new System.Drawing.Point(109, 9);
            this.lb_ucbank2.Name = "lb_ucbank2";
            this.lb_ucbank2.Size = new System.Drawing.Size(114, 29);
            this.lb_ucbank2.TabIndex = 9;
            this.lb_ucbank2.Text = "UC Bank";
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.txtbox_deposit);
            this.panel_deposit.Controls.Add(this.lb_input);
            this.panel_deposit.Controls.Add(this.btn_deposituang);
            this.panel_deposit.Controls.Add(this.button4);
            this.panel_deposit.Controls.Add(this.label4);
            this.panel_deposit.Location = new System.Drawing.Point(788, 51);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(335, 321);
            this.panel_deposit.TabIndex = 17;
            // 
            // txtbox_deposit
            // 
            this.txtbox_deposit.Location = new System.Drawing.Point(123, 122);
            this.txtbox_deposit.Name = "txtbox_deposit";
            this.txtbox_deposit.Size = new System.Drawing.Size(100, 22);
            this.txtbox_deposit.TabIndex = 16;
            // 
            // lb_input
            // 
            this.lb_input.AutoSize = true;
            this.lb_input.Location = new System.Drawing.Point(101, 97);
            this.lb_input.Name = "lb_input";
            this.lb_input.Size = new System.Drawing.Size(139, 16);
            this.lb_input.TabIndex = 15;
            this.lb_input.Text = "Input Deposit Amount :";
            // 
            // btn_deposituang
            // 
            this.btn_deposituang.Location = new System.Drawing.Point(133, 163);
            this.btn_deposituang.Name = "btn_deposituang";
            this.btn_deposituang.Size = new System.Drawing.Size(75, 27);
            this.btn_deposituang.TabIndex = 13;
            this.btn_deposituang.Text = "Deposit";
            this.btn_deposituang.UseVisualStyleBackColor = true;
            this.btn_deposituang.Click += new System.EventHandler(this.btn_deposituang_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(223, 50);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 27);
            this.button4.TabIndex = 12;
            this.button4.Text = "Log Out";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(109, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 29);
            this.label4.TabIndex = 9;
            this.label4.Text = "UC Bank";
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.lb_nominalshow);
            this.panel_withdraw.Controls.Add(this.lb_balanceshow);
            this.panel_withdraw.Controls.Add(this.label5);
            this.panel_withdraw.Controls.Add(this.txtbox_withdraw);
            this.panel_withdraw.Controls.Add(this.label2);
            this.panel_withdraw.Controls.Add(this.btn_withdrawuang);
            this.panel_withdraw.Controls.Add(this.button7);
            this.panel_withdraw.Controls.Add(this.label3);
            this.panel_withdraw.Location = new System.Drawing.Point(788, 51);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(335, 321);
            this.panel_withdraw.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(167, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 25);
            this.label5.TabIndex = 21;
            // 
            // txtbox_withdraw
            // 
            this.txtbox_withdraw.Location = new System.Drawing.Point(106, 167);
            this.txtbox_withdraw.Name = "txtbox_withdraw";
            this.txtbox_withdraw.Size = new System.Drawing.Size(109, 22);
            this.txtbox_withdraw.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(88, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "Input Withdrawal Amount :";
            // 
            // btn_withdrawuang
            // 
            this.btn_withdrawuang.Location = new System.Drawing.Point(114, 209);
            this.btn_withdrawuang.Name = "btn_withdrawuang";
            this.btn_withdrawuang.Size = new System.Drawing.Size(93, 27);
            this.btn_withdrawuang.TabIndex = 14;
            this.btn_withdrawuang.Text = "Withdraw";
            this.btn_withdrawuang.UseVisualStyleBackColor = true;
            this.btn_withdrawuang.Click += new System.EventHandler(this.btn_withdrawuang_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(223, 50);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 27);
            this.button7.TabIndex = 12;
            this.button7.Text = "Log Out";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(109, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 29);
            this.label3.TabIndex = 9;
            this.label3.Text = "UC Bank";
            // 
            // panel_login
            // 
            this.panel_login.Controls.Add(this.lb_ucbank);
            this.panel_login.Controls.Add(this.btn_login);
            this.panel_login.Controls.Add(this.btn_register);
            this.panel_login.Controls.Add(this.txtbox_usn);
            this.panel_login.Controls.Add(this.txtbox_pass);
            this.panel_login.Controls.Add(this.lb_usn);
            this.panel_login.Controls.Add(this.lb_pass);
            this.panel_login.Location = new System.Drawing.Point(788, 51);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(240, 242);
            this.panel_login.TabIndex = 19;
            // 
            // lb_balanceshow
            // 
            this.lb_balanceshow.AutoSize = true;
            this.lb_balanceshow.Location = new System.Drawing.Point(88, 93);
            this.lb_balanceshow.Name = "lb_balanceshow";
            this.lb_balanceshow.Size = new System.Drawing.Size(57, 16);
            this.lb_balanceshow.TabIndex = 21;
            this.lb_balanceshow.Text = "Balance";
            // 
            // lb_nominalshow
            // 
            this.lb_nominalshow.AutoSize = true;
            this.lb_nominalshow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nominalshow.Location = new System.Drawing.Point(166, 91);
            this.lb_nominalshow.Name = "lb_nominalshow";
            this.lb_nominalshow.Size = new System.Drawing.Size(0, 25);
            this.lb_nominalshow.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1286, 835);
            this.Controls.Add(this.panel_login);
            this.Controls.Add(this.panel_regis);
            this.Controls.Add(this.panel_balance);
            this.Controls.Add(this.panel_withdraw);
            this.Controls.Add(this.panel_deposit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_regis.ResumeLayout(false);
            this.panel_regis.PerformLayout();
            this.panel_balance.ResumeLayout(false);
            this.panel_balance.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.TextBox txtbox_usn;
        private System.Windows.Forms.TextBox txtbox_pass;
        private System.Windows.Forms.Label lb_usn;
        private System.Windows.Forms.Label lb_pass;
        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Panel panel_regis;
        private System.Windows.Forms.Label lb_usnpass;
        private System.Windows.Forms.TextBox txtbox_usnregis;
        private System.Windows.Forms.Label lb_usnregis;
        private System.Windows.Forms.TextBox txtbox_passregis;
        private System.Windows.Forms.Button btn_regis;
        private System.Windows.Forms.Panel panel_balance;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Label lb_ucbank2;
        private System.Windows.Forms.Label lb_nominal;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button btn_wd;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.Label lb_input;
        private System.Windows.Forms.Button btn_deposituang;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbox_deposit;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.TextBox txtbox_withdraw;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_withdrawuang;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_nominalshow;
        private System.Windows.Forms.Label lb_balanceshow;
    }
}

